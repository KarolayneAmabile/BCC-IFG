from orator import Model

class Candidato(Model):
    __table__ = 'candidato'
    __timestamps__ = False
    __fillable__ = [
        'nome', 'cpf', 'data_nascimento', 'categoria',
        'curso_id', 'nota'
    ]

    CATEGORIAS_VALIDAS = [
        'Ampla Concorrência',
        'PPI - Pública - Baixa Renda',
        'Pública - Baixa Renda',
        'PPI - Pública',
        'Pública',
        'Deficientes'
    ]

    def validate(self):
        if not self.nome or len(self.nome.strip()) == 0:
            self.error = 'Nome do candidato é obrigatório'
            return False
        if not self.cpf or len(self.cpf) != 11 or not self.cpf.isdigit():
            self.error = 'CPF deve ter 11 dígitos numéricos'
            return False
        if self.categoria not in self.CATEGORIAS_VALIDAS:
            self.error = f'Categoria inválida: {self.categoria}'
            return False
        if self.cpf_exists():
            self.error = 'CPF já cadastrado'
            return False
        return True
    
    def cpf_exists(self):
        query = Candidato.where('cpf', self.cpf)
        if hasattr(self, 'id') and self.id:
            query = query.where('id', '!=', self.id)
        return query.exists()

    def save(self, **kwargs):
        if self.validate():
            return super().save()
        return False