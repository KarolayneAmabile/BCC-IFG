# Importe a classe DB
from orator import Model
from orator.exceptions.query import QueryException
from models.EdicaoCurso import EdicaoCurso

class Edicao(Model):
    __table__ = 'edicao'
    __timestamps__ = False
    __fillable__ = ['nome']

    many_to_many_fields = {
        "cursos": EdicaoCurso
    }

    def validate(self):
        if not self.nome or len(self.nome.strip()) == 0:
            self.error = 'Nome da edição é obrigatório'
            return False
        if not self.nome.upper().startswith('SISU '):
            self.error = 'Nome da edição deve iniciar com "SISU "'
            return False
        return True

    def save(self, **kwargs):
        if self.validate():
            return super().save()
        return False

    def save_many(self, nested_data):
        if not self.validate():
            return False

        edicao_cursos_list = nested_data.get("cursos", [])

        db = Edicao.get_connection_resolver()
        conn = db.connection(self.get_connection_name())

        conn.begin_transaction()
        try:
            super(Edicao, self).save()

            for edicao_curso in edicao_cursos_list:
                if not isinstance(edicao_curso, EdicaoCurso):
                    self.error = f'O objeto {edicao_curso} não é uma instância de EdicaoCurso.'
                    conn.rollback()
                    return False
                if not edicao_curso.validate():
                    self.error = f'Erro de validação no EdicaoCurso: {edicao_curso.error}'
                    conn.rollback()
                    return False

            EdicaoCurso.where('edicao_id', self.id).delete()

            for edicao_curso in edicao_cursos_list:
                edicao_curso.edicao_id = self.id
                edicao_curso.save()

            conn.commit()
            return True

        except Exception as e:
            conn.rollback()
            self.error = str(e)
            raise QueryException(self, [], e)