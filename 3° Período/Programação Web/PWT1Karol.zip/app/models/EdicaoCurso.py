from orator import Model

class EdicaoCurso(Model):
    __table__ = 'edicao_curso'
    __timestamps__ = False
    __fillable__ = [
        'edicao_id', 'curso_id',
        'vagas_ac', 'vagas_ppi_br', 'vagas_publica_br',
        'vagas_ppi_publica', 'vagas_publica', 'vagas_deficientes'
    ]

    @classmethod
    def get_vagas_by_edicao(cls, edicao_id=None):
        registros = cls.where('edicao_id', edicao_id).get()
        return {str(reg.curso_id): reg for reg in registros}

    def validate(self):
        campos_int = [
            'vagas_ac', 'vagas_ppi_br', 'vagas_publica_br',
            'vagas_ppi_publica', 'vagas_publica', 'vagas_deficientes'
        ]
        for campo in campos_int:
            valor = getattr(self, campo, None)
            try:
                valor = int(valor)
                if valor < 0:
                    raise ValueError
                setattr(self, campo, valor)
            except (TypeError, ValueError):
                self.error = f'O campo {campo} deve ser um inteiro >= 0'
                return False
        return True
    
    def save(self, **kwargs):
        if self.validate():
            return super().save()
        return False
    
    def __str__(self):
        campos = []
        for field in self.__fillable__:
            valor = getattr(self, field, None)
            campos.append(f"{field}={valor!r}({type(valor).__name__})")
        return f"EdicaoCurso({', '.join(campos)})"
    
    def to_dict(self):
        return {attr: getattr(self, attr) for attr in self.__fillable__}