from orator import Model

class Curso(Model):
    __table__ = 'curso'
    __timestamps__ = False
    __fillable__ = ['nome']

    def validate(self):
        if not self.nome or len(self.nome.strip()) == 0:
            self.error = 'Nome do curso é obrigatório'
            return False
        return True

    def save(self, **kwargs):
        if self.validate():
            return super().save()
        return False