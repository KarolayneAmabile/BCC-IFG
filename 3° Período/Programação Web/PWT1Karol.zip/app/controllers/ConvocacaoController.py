# CandidatoController.py
import sys
import logging
sys.path.append('./app')
from models.Candidato import Candidato
from models.Edicao import Edicao
from models.Curso import Curso
from models.EdicaoCurso import EdicaoCurso
from controllers.Controller import Controller

class ConvocacaoController(Controller):
    def index(self):
        edicoes = Edicao.all()
        cursos = Curso.all()

        template = self.env.get_template("index.html")
        self.data = template.render(edicoes=edicoes, cursos=cursos)

    def convocate(self, edition_id, course_id, x):
        edicao = Edicao.find(edition_id[0])
        curso = Curso.find(course_id[0])

        edicao_curso = EdicaoCurso.where('edicao_id', edition_id[0]).where('curso_id', course_id[0]).first()
        if not edicao_curso: return {}

        categorias = Candidato.CATEGORIAS_VALIDAS
        vagas_por_categoria = {
            'Ampla Concorrência': edicao_curso.vagas_ac,
            'PPI - Pública - Baixa Renda': edicao_curso.vagas_ppi_br,
            'Pública - Baixa Renda': edicao_curso.vagas_publica_br,
            'PPI - Pública': edicao_curso.vagas_ppi_publica,
            'Pública': edicao_curso.vagas_publica,
            'Deficientes': edicao_curso.vagas_deficientes,
        }

        candidatos_categoria = {}
        for categoria in categorias:
            V_M = vagas_por_categoria.get(categoria, 0)

            N_M = V_M * int(x[0])
            if N_M <= 0: 
                candidatos_categoria[categoria] = []
                continue
            
            candidatos = (
                Candidato
                .where('curso_id', course_id)
                .where('categoria', categoria)
                .order_by('nota', 'desc')
                .limit(N_M)
                .get()
            )
            candidatos_categoria[categoria] = candidatos

        template = self.env.get_template("convocate.html")
        self.data = template.render(edicao=edicao, curso=curso, candidatos_por_categoria=candidatos_categoria)