# EdicaoController.py
import sys
sys.path.append('./app')
from models.Edicao import Edicao
from models.Curso import Curso
from models.EdicaoCurso import EdicaoCurso
from controllers.Controller import Controller

class EdicaoController(Controller):
    def index(self):
        edicoes = Edicao.all()
        template = self.env.get_template("index.html")
        self.session['flash'] = ''
        self.data = template.render(edicoes=edicoes, session=self.session)

    def view(self, id):
        import logging
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
        logging.info(f"Iniciando a função view com id: {id}")
        
        try:
            edicao = Edicao.find(id[0])
            logging.info(f"Edição encontrada: {edicao.nome}")
            
            cursos = EdicaoCurso.get_vagas_by_edicao(edicao_id=id[0])
            logging.info(f"Cursos e vagas obtidos: {cursos}")

            cursos_vagas = []
            for k, i in cursos.items():
                logging.debug(f"Processando curso com ID: {k}")
                curso = Curso.find(k).nome
                logging.debug(f"Nome do curso encontrado: {curso}")
                cursos_vagas.append({**i.to_dict(), **{"nome": curso}})
            
            logging.info(f"Lista final de cursos_vagas: {cursos_vagas}")

            template = self.env.get_template("view.html")
            logging.info("Template 'index.html' obtido com sucesso.")
            
            self.data = template.render(edicao=edicao, cursos_vagas=cursos_vagas)
            logging.info("Template renderizado com sucesso.")
            
        except Exception as e:
            logging.error(f"Ocorreu um erro durante a execução: {e}")
            # Aqui você pode adicionar um raise para propagar o erro
            # ou um return para lidar com ele de outra forma.

    def create(self):
        method = self.environ["REQUEST_METHOD"]
        template = self.env.get_template("create.html")
        edicao = Edicao()
        cursos = Curso.all()
        
        if method == "POST":
            cursos_obj = self.loadNestedForm(edicao)

            if edicao.save_many(cursos_obj):
                self.redirectPage('index')

        self.data = template.render(edicao=edicao, cursos=cursos)

    def update(self, id):
        import logging
        logging.basicConfig(level=logging.DEBUG)
        logger = logging.getLogger(__name__)

        method = self.environ["REQUEST_METHOD"]
        edicao = Edicao.find(id[0])
        cursos = Curso.all()
        vagas = EdicaoCurso.get_vagas_by_edicao(edicao.id)
        template = self.env.get_template("create.html")

        if not edicao:
            self.notFound()
            return

        if method == "POST":
            cursos_obj = self.loadNestedForm(edicao)

            if edicao.save_many(cursos_obj):
                self.redirectPage('index')

        self.data = template.render(edicao=edicao, cursos=cursos, vagas=vagas)

    def delete(self, id):
        edicao = Edicao.find(id[0])
        if edicao:
            EdicaoCurso.where('edicao_id', '=', edicao.id).delete()
            edicao.delete()
            self.session['flash'] = 'Edição deletada com sucesso'
            self.redirectPage('index')
        else:
            self.notFound()