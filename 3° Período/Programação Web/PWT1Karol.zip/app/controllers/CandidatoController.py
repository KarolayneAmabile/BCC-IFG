# CandidatoController.py
import sys
sys.path.append('./app')
from models.Candidato import Candidato
from models.Curso import Curso
from controllers.Controller import Controller

class CandidatoController(Controller):
    def index(self):
        candidatos = Candidato.all()
        template = self.env.get_template("index.html")
        self.data = template.render(candidatos=candidatos)

    def view(self, id):
        candidato = Candidato.find(id[0])
        curso = Curso.find(candidato.curso_id)

        if candidato:
            template = self.env.get_template("view.html")
            self.data = template.render(candidato=candidato, curso=curso)
        else:
            self.notFound()
            return
        

    def create(self):
        method = self.environ["REQUEST_METHOD"]
        template = self.env.get_template("create.html")
        candidato = Candidato()
        cursos = Curso.all()
        if method == "POST":
            self.loadForm(candidato)
            if candidato.save():
                self.redirectPage('index')
        
        self.data = template.render(candidato=candidato, cursos=cursos)

    def update(self, id):
        method = self.environ["REQUEST_METHOD"]
        template = self.env.get_template("create.html")
        candidato = Candidato.find(id[0])
        cursos = Curso.all()
        if candidato:
            if method == "POST":
                self.loadForm(candidato)
                if candidato.save():
                    self.redirectPage('index')
            self.data = template.render(candidato=candidato, cursos=cursos)
        else:
            self.notFound()
            return
            
    def delete(self, id):
        candidato = Candidato.find(id[0])
        if candidato:
            candidato.delete()
            self.session['flash'] = 'Candidato deletado com sucesso'
            self.redirectPage('index')
        else:
            self.notFound()