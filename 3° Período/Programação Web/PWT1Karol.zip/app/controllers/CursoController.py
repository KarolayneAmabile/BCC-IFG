import sys
sys.path.append('./app')
from models.Curso import Curso
from controllers.Controller import Controller


class CursoController(Controller):

    def index(self):
        cursos = Curso.all()

        template = self.env.get_template("index.html")
        self.data = template.render(cursos=cursos)

    def create(self):
        method = self.environ["REQUEST_METHOD"]
        template = self.env.get_template("create.html")

        curso = Curso()
        if method == "POST":
            self.loadForm(curso)
            if curso.save():
                self.redirectPage('index')

        self.data = template.render(curso=curso)

    def update(self, id):
        method = self.environ["REQUEST_METHOD"]
        template = self.env.get_template("create.html")
        curso = Curso.find(id[0])

        if curso:
            if method == "POST":
                self.loadForm(curso)
                if curso.save():
                    self.redirectPage('index')
        else:
            self.notFound()
            return

        self.data = template.render(curso=curso)


    def delete(self, id):
        curso = Curso.find(id[0])

        if curso:
            curso.delete()
            self.session['flash'] = 'Feedback Deletado com sucesso'
            self.redirectPage('index')
        else:
            self.notFound()
