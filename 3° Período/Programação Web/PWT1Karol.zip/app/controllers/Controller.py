from jinja2 import Environment, FileSystemLoader
import os
import cgi
from html import escape
from urllib.parse import urlencode

class Controller:
    def __init__(self,env):
        self.environ=env
        self.data = ""
        self.status = "200 OK"
        self.redirect_url = ""
        self.session = env['session']
        self.nome=(self.__class__.__name__).lower()[:-len("controller")]
        template_dirs = [
            os.path.join(os.getcwd(), 'views', 'public'),
            os.path.join(os.getcwd(), 'views', self.nome)
        ]
        self.env = Environment(loader=FileSystemLoader(template_dirs))

    def form2dict(self,form):
        dict ={}
        for  key in form:
            dict[key]= escape(form.getvalue(key))
        return dict
    
    def form2nested_dict(self, form):
        nested = {}
        for key in form:
            value = escape(form.getvalue(key))

            if "[" in key and "]" in key:
                parts = key.replace("[", "!%!").replace("]", "").split("!%!")
                list_name, index, attribute = parts[0], int(parts[1]), parts[2]

                if list_name not in nested: nested[list_name] = []
                while len(nested[list_name]) <= index:
                    nested[list_name].append({})

                nested[list_name][index][attribute] = value
            else:
                nested[key] = value
        
        return nested
    
    def loadForm(self, model):
        form = cgi.FieldStorage(fp=self.environ["wsgi.input"], environ=self.environ)
        model.fill(self.form2dict(form))

    def loadNestedForm(self, model):
        form = cgi.FieldStorage(fp=self.environ["wsgi.input"], environ=self.environ)
        nested_form = self.form2nested_dict(form)

        nested_fields = getattr(model, 'many_to_many_fields', {})
        not_nested_fields = [field for field in nested_form if field not in nested_fields.keys()]
        not_nested_data = {field: nested_form[field] for field in not_nested_fields}

        model.fill(not_nested_data)

        nested_obj = {}
        for field, obj_type in nested_fields.items():
            nested_obj[field] = []

            for nested_data in nested_form.get(field, []):
                new_obj = obj_type()
                new_obj.fill(nested_data)
                nested_obj[field].append(new_obj)

        return nested_obj


    def redirectPage(self,path:str,params=None):
        self.status = "302 OK"
        self.redirect_url = f'/app/{self.nome}/{path}'
        if params:
            self.redirect_url += f'?{urlencode(params)}'

    def notFound(self):
        self.status = "404 Not Found"
        template = Environment(loader=FileSystemLoader(os.getcwd()+f'/views/public')).get_template("404.html")
        self.data=template.render()